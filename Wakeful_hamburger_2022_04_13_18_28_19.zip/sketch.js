function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(235,142,98);
  
  circle(200,250,190);
  fill(12,228,166);
  circle(200,250,125);
  ellipseMode(CENTER);
fill(60);
  circle(200,250,20);
  fill(111,247,200);
  noStroke();
}